/*SERVER GAMEPLAY*/
#include<stdlib.h>
#include<conio.h>
#include<stdio.h>
#include<winsock2.h>
int serverKey,clientKey;
char mar[4][3]; //row 4 becoz NULL char ;col 3 no null
int i,j,k;
int count=0;
int keylist[9];
int key;
int check();
void display();
void input(int);
void initial();
void gamefun(int);
void replay();
int flag;
int main()
{
int choice;
    WSADATA wsa;
SOCKET master,slave=0,new_socket;
struct sockaddr_in server, address;
int activity, addrlen, i, valread;
char msg[512],*rcvdmsg,*uInput;
     rcvdmsg=(char *)malloc(512*sizeof(char));
    int recv_size, rcvdmsg_len, c;
    int MAXRECV = 512;
    struct timeval t1;
    t1.tv_sec=1L;
    t1.tv_usec=0L;
//set of socket descriptors
    fd_set readfds;
    //1 extra for null character, string termination
    char *buffer;
    buffer =  (char*) malloc((512) * sizeof(char));
 printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        exit(EXIT_FAILURE);
    }
    printf("Initialised.\n");
      //Create a socket
    if((master = socket(AF_INET , SOCK_STREAM , 0 )) == INVALID_SOCKET)
    {
        printf("Could not create socket : %d" , WSAGetLastError());
        exit(EXIT_FAILURE);
    }
    printf("Socket created.\n");
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
   // server.sin_addr.s_addr = "192.168.43.141";
    server.sin_port = htons( 7777 );
    //Bind
    if( bind(master ,(struct sockaddr *)&server , sizeof(server)) == SOCKET_ERROR)
    {
        printf("Bind failed with error code : %d" , WSAGetLastError());
        exit(EXIT_FAILURE);
    }
    puts("Bind done");
    //Listen to incoming connections
    listen(master , 3);
  puts("Waiting for incoming connections...");
 //getch();
   addrlen = sizeof(struct sockaddr_in);

printf("\n\n############################### \n###Multi Player Tic Tac Toe ###\n###############################\n\n\
       AKA XOXO \n\
       This is a multi-player game \n\
       To play NUM-pad acts as input \n7-8-9\n4-5-6\n1-2-3\n\n\
       You are SERVER/Player 2 ");
//getch();
Sleep(3000);
   display();
   initial();//set up board
while(1){
        //clear the socket fd set
        FD_ZERO(&readfds);

        //add master socket to fd set
        FD_SET(master, &readfds);

        //add child sockets to fd set
      if(slave>0)
            FD_SET( slave , &readfds);

          //wait for an activity on any of the sockets, timeout is NULL , so wait indefinitely
        activity = select( 0 , &readfds , NULL , NULL , NULL);
        //activity=select(0,&read)

        if ( activity == SOCKET_ERROR )
        {
            printf("select call failed with error code : %d" , WSAGetLastError());
            exit(EXIT_FAILURE);
        }
        //yha tak
         //If something happened on the master socket , then its an incoming connection
        if (FD_ISSET(master , &readfds))
        {

            if ((new_socket = accept(master , (struct sockaddr *)&address, (int *)&addrlen))<0)
            {
                perror("accept");
                exit(EXIT_FAILURE);
            }

            /*inform user of socket number - used in send and receive commands
            printf("New connection , socket fd is %d , ip is : %s , port : %d \n" , new_socket , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));*/
        if(slave==0)
            slave=new_socket;
        //FD_SET(new_socket,&readfds);
        }
        /*Client Code down*/
        if (FD_ISSET( slave , &readfds)){
            display();
            printf("\nWaiting for Player 1 (Client): ");
            valread = recv( slave , buffer, 512, 0);

         if( valread == SOCKET_ERROR)
                {
                    int error_code = WSAGetLastError();
                    if(error_code == WSAECONNRESET)
                    {
                        //Somebody disconnected , get his details and print
                        printf("Host disconnected unexpectedly , ip %s , port %d \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));
                        getch();
                        //Close the socket and mark as 0 in list for reuse
                        closesocket( slave );

                    }
                    else
                    {
                        printf("recv failed with error code : %d" , error_code);
                        getch();
                    }
                }
                else if ( valread == 0)
                {
                    //Somebody disconnected , get his details and print
                    printf("Host disconnected , ip %s , port %d \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));
                    getch();
                    //Close the socket and mark as 0 in list for reuse
                    closesocket( slave );

                }
                else
                {
                    /*this is my client data convert SCANF for p2*/
                    /*add null character, if you want to use with printf/puts or other string handling functions*/
                    buffer[valread] = '\0';
                     gamefun(atoi(buffer));
                   // printf("%s:%d - %s \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port), buffer);
                      //  printf("#counnt : %d",count);
                        reEnter:
                    fflush(stdin);
                    printf("\nPlayer 2 Turn (Server): ");
                    gets(msg);

                    if(atoi(msg)>0 && atoi(msg)<10){
                        send( slave , msg , strlen(msg) , 0 );
                        gamefun(atoi(msg));
                    }
                    else{
                        printf("please enter no. between 1-9:");
                        goto reEnter;
                    }

 }
}
}
return 0;
}
void gamefun(int key){
	if(key<=9 && key!=0)
	{
		input(key);

	}
	else
        count--;
count++;
display();
	flag = 0;
	flag = check();
	if (flag==88)//88 ascii of caps X
	{
		printf("player 1 wins!!! ");
		getch();
		exit(0);
//		break;
	}
	if(flag==79) //79 Ascii of caps O
	{
		printf("Player 2 Wins!!!");
		getch();
		exit(0);
	//	break;
	}

    if(count==9){
        printf("\nTie  \n");
        getch();
        exit(0);
    }



}
void display()
{
	system("cls");
	printf("################## \n###tic tac toe ###\n##################\n\n");
	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	printf("|%c",mar[i][j]);
        printf("|");
	}
	printf("\n");
	printf("---------");
	printf("\n");
	}
	printf("\n#### tic tac toe (beta 2) ###\n");
	//printf("\ncount= ",count);
    printf("\n");
}
void input(int n)
{
	char u;
	if(count%2==0)
		u='X';
	else
		u='O';
	switch(n)
	{

		case 7:
			if(mar[0][0]==0)
		 mar[0][0]=u;

			break;
		case 8:
			if(mar[0][1]==0)
			mar[0][1]=u;
			break;
		case 9:
			if(mar[0][2]==0)
			mar[0][2]=u;
			break;
		case 4:
			if(mar[1][0]==0)
			mar[1][0]=u;
			break;
		case 5:
			if(mar[1][1]==0)
			mar[1][1]=u;
			break;
		case 6:
			if(mar[1][2]==0)
			mar[1][2]=u;
			break;
		case 1:
			if(mar[2][0]==0)
			mar[2][0]=u;
			break;
		case 2:
			if(mar[2][1]==0)
			mar[2][1]=u;
			break;
		case 3:
			if(mar[2][2]==0)
			mar[2][2]=u;
			break;
	}
}
int check()
{
	//int s;
	int ret_val;
	//all row check
	//int k;
	for(i=0,j=0;i<3;i++)
	{

			if(mar[i][j]==mar[i][j+1] && mar[i][j]!=0 && mar[i][j+1]!=0)
			{
				if(mar[i][j+1]==mar[i][j+2])
				{
				ret_val=mar[i][j];
				break;
			 	}
			}
			//DIAGNOL
			if(mar[0][0]==mar[1][1] && mar[1][1]==mar[2][2] &&mar[1][1]!=0)
			{
				ret_val=mar[1][1];
				break;
			}
			if(mar[1][1]==mar[0][2] && mar[0][2] ==mar[2][0] &&mar[1][1]!=0)
			{
				ret_val=mar[1][1];
				break;
			}
		}
		//VERTICAL
		for(i=0,j=0;j<3;j++)
		{
			if(mar[i][j]==mar[i+1][j] && mar[i][j]!=0 && mar[i+1][j]!=0)
			{
				if(mar[i+1][j]==mar[i+2][j])
				{
				ret_val=mar[i][j];
				break;
			 	}
			}
		}
	return(ret_val) ;
}

void initial()
{
//initializer
for(i=0;i<3;i++)
{
	for(j=0;j<3;j++)
	mar[i][j]=0;
}
}
