#include<stdio.h>
#include<winsock2.h>
int serverKey,clientKey;
char mar[4][3]; //row 4 becoz NULL char ;col 3 no null
int i,j,k;
int count=0;
int keylist[9];
int key;
int check();
void display();
void input(int);
void initial();
void gamefun();
int flag;

int main()
{
    WSADATA wsa;
    SOCKET sock;
    struct sockaddr_in server;
    char msg[512], *rcvdmsg,*uInput;
     char *buffer;
    //char msg[512]="hello server";
    int recv_size, rcvdmsg_len=512;
    int activity, addrlen, i, valread;
    fd_set readfds;
    int MAXRECV = 512;
    rcvdmsg =  (char*) malloc((MAXRECV + 1) * sizeof(char));

    struct timeval t1;

    t1.tv_sec=1L;
    t1.tv_usec=0L;
    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
    {
        printf("Failed. Error Code : %d",WSAGetLastError());
        getch();
        return 1;
    }

    printf("Initialised.\n");

    //Create a socket
    if((sock = socket(AF_INET , SOCK_STREAM , 0 )) == INVALID_SOCKET)
    {
        printf("Could not create socket : %d" , WSAGetLastError());
        getch();
        return 1;
    }

    printf("Socket created.\n");


    // server.sin_addr.s_addr = inet_addr("192.168.43.141");
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    //server.sin_port = htons( 7777 );
    server.sin_port = htons( 7777 );

    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        puts("connect error");
        getch();
        return 1;
    }

    puts("Connected");
    Sleep(3000);
    display();
while(1){
    //Send some data
    printf("Your Turn: ");
    fflush(stdin);
    reEnter:
    gets(msg);
    if(atoi(msg)>0 && atoi(msg)<10){
    gamefun(atoi(msg));
    if( send(sock , msg , strlen(msg) , 0) < 0)
    {
        puts("Send failed");
        getch();
        return 1;
    }
    }
    else{
         printf("please enter no. between 1-9:");
         goto reEnter;
    }
        FD_ZERO(&readfds);
        //add master socket to fd set
        FD_SET(sock, &readfds);
         activity = select( 0 , &readfds , NULL , NULL , NULL);

        if ( activity == SOCKET_ERROR )
        {
            printf("select call failed with error code : %d" , WSAGetLastError());
            exit(EXIT_FAILURE);
        }
          if (FD_ISSET( sock , &readfds)){
            valread = recv( sock , rcvdmsg, 512, 0);

         if( valread == SOCKET_ERROR)
                {
                    int error_code = WSAGetLastError();
                    if(error_code == WSAECONNRESET)
                    {
                        printf("Somebody disconnected ");
                        //printf("Host disconnected unexpectedly , ip %s , port %d \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));
                        //Close the socket and mark as 0 in list for reuse
                        closesocket( sock );

                    }
                    else
                    {
                        printf("recv failed with error code : %d" , error_code);
                    }
                }
                else if ( valread == 0)
                {
                    printf("Somebody disconnected , get his details and print");
            //        printf("Host disconnected , ip %s , port %d \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));

                    //Close the socket and mark as 0 in list for reuse
                    closesocket( sock );

                }

                else
                {

                    //add null character, if you want to use with printf/puts or other string handling functions
                    rcvdmsg[valread] = '\0';
                 // printf("%s:%d - %s \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port), buffer);
                puts(rcvdmsg);
                gamefun(atoi(rcvdmsg));
 }
}
}
getch();

    closesocket(sock);
    WSACleanup();
    getch();
    return 0;
}
void gamefun(int key){
	if(key<=9 && key!=0)
	{
		input(key);

	}
	else
        count--;
count++;
display();
	flag = 0;
	flag = check();
	//printf("flag=%d",flag);
	if (flag==88)//88 ascii of caps X
	{
		printf("player 1 wins!!! ");
		getch();
//		break;
	}
	if(flag==79) //79 Ascii of caps O
	{
		printf("Player 2 Wins!!!");
		getch();
	//	break;
	}
    if(count==9)
        printf("\nTie  \n");
}
void display()
{
	system("cls");
	printf("################## \n###tic tac toe ###\n##################\n\n");
	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	{
	printf("|%c",mar[i][j]);
        printf("|");
	}
	printf("\n");

	printf("---------");

	printf("\n");

	}

	printf("\n#### tic tac toe (beta 2) ###\n");
	//printf("\ncount= %d",count);
    printf("\n");
}

void input(int n)
{

	char u;
	if(count%2==0)
		u='X';
	else
		u='O';

	switch(n)
	{

		case 7:
			if(mar[0][0]==0)
		 mar[0][0]=u;

			break;
		case 8:
			if(mar[0][1]==0)
			mar[0][1]=u;
			break;
		case 9:
			if(mar[0][2]==0)
			mar[0][2]=u;
			break;
		case 4:
			if(mar[1][0]==0)
			mar[1][0]=u;
			break;
		case 5:
			if(mar[1][1]==0)
			mar[1][1]=u;
			break;
		case 6:
			if(mar[1][2]==0)
			mar[1][2]=u;
			break;
		case 1:
			if(mar[2][0]==0)
			mar[2][0]=u;
			break;
		case 2:
			if(mar[2][1]==0)
			mar[2][1]=u;
			break;
		case 3:
			if(mar[2][2]==0)
			mar[2][2]=u;
			break;
	}
}

int check()
{
	//int s;
	int ret_val;
	//all row check
	//int k;
	for(i=0,j=0;i<3;i++)
	{

			if(mar[i][j]==mar[i][j+1] && mar[i][j]!=0 && mar[i][j+1]!=0)
			{
				if(mar[i][j+1]==mar[i][j+2])
				{
				ret_val=mar[i][j];
				break;
			 	}
			}
			//DIAGNOL
			if(mar[0][0]==mar[1][1] && mar[1][1]==mar[2][2] &&mar[1][1]!=0)
			{
				ret_val=mar[1][1];
				break;
			}
			if(mar[1][1]==mar[0][2] && mar[0][2] ==mar[2][0] &&mar[1][1]!=0)
			{
				ret_val=mar[1][1];
				break;
			}
		}
		//VERTICAL
		for(i=0,j=0;j<3;j++)
		{
			if(mar[i][j]==mar[i+1][j] && mar[i][j]!=0 && mar[i+1][j]!=0)
			{
				if(mar[i+1][j]==mar[i+2][j])
				{
				ret_val=mar[i][j];
				break;
			 	}
			}
		}
	return(ret_val) ;
}

void initial()
{
//initializer
for(i=0;i<3;i++)
{
	for(j=0;j<3;j++)
	mar[i][j]=0;
}
}
